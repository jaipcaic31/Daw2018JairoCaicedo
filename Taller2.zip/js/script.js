function addNew(autor, contenido,href, time) {
   var title = $("<h5/>", {
      "class": "autor",
      html: autor
    });

    var p = $("<p/>",{
      "class": "contenido",
      html: contenido
    });

    var div = $( "<div/>", {
      "class": "tweet"
    });

    var url = $("<a/>",{
      "href": href,
      html: href
    });

    var time = $("<time/>",{
      html: time
    });
    var hr = $("<hr/>");

    title.appendTo(div);
    p.appendTo(div);
    url.appendTo(div);
    time.appendTo(div);
    hr.appendTo(div);
    div.appendTo( "#noticias" );
}
function loadNewsXml() {
  $.ajax({
      type: "GET",
      url: "noticias.xml",
      dataType: "xml",
      success: function(xml){
          $(xml).find('item').each(function(){
            var autor = $(this).find('dc:creator').text();
            var contenido = $(this).find('title').text();
            var href = $(this).find('link').text();
            var time = $(this).find('pubDate').text();
            addNew(autor, contenido,href,time)
          });
      },
      error: function() {
        alert("Error al procesar el xml");
      }
  });
}

$(document).ready(function(){
  loadNewsXml();

  $("button").click(function(e){

    var texto = $('input#buscador').val();
    var ingresar = $("<h1/>", {
      html: texto
    });
    ingresar.appendTo("#texto")
    
    if(texto.length != 0) {
      
      var noticias = $('#noticias .tweet');
      $('#noticias .tweet').filter(function(index){
        
        $(this).show();
        
        var noticia = $(this).text()
        if(noticia.indexOf(texto) == -1) {
          $(this).hide()
        }

      });

    } else {
      $('#noticias .tweet').each(function(){
        $(this).show();
      });
    }
    return false;
  })
});